from django.apps import AppConfig


class FestivalConfig(AppConfig):
    name = 'Festival'
