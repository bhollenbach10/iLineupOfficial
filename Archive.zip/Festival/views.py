from django.shortcuts import render
from django.http import HttpResponse
from django.template import loader
from .models import *
from django.shortcuts import render
from django.http import HttpResponseRedirect
from .forms import NameForm






# Create your views here.
def index(request):
    template = loader.get_template('index.html')
    context = {
        'categories': Category.objects.all(), }
    return HttpResponse(template.render(context, request))


def product(request, id=1):
    template = loader.get_template('product.html')
    context = {
        'product': Product.objects.get(id=id)
    }
    return HttpResponse(template.render(context, request))

def product_artist(request):
    if request.method == 'POST':
        form = NameForm(request.post)
        if form.is_valid():
            return HttpResponseRedirect('/thanks/')
        else:
            form = NameForm()
        return render(request, 'name.html' , {'form': form})

